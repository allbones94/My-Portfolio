name = raw_input("Please enter your name: ");
print "Hello",name,"welcome to the world of Python Programming"
