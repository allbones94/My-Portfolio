print "hello, world";
