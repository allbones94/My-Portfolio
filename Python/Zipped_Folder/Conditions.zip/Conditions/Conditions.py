a = 3
b = 2

if a < b:
    print str(b)+" is more than "+str(a)
else:
    print str(a)+" is more than "+str(b)
